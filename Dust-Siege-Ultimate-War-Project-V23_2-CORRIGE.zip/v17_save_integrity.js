/* DUST SIEGE V17 — vérification des sauvegardes et diagnostic non intrusif.
   Patch additif : conserve les clés et le format de sauvegarde existants. */
(() => {
  'use strict';
  if (window.__dsV17IntegrityInstalled) return;
  window.__dsV17IntegrityInstalled = true;

  const SAVE_KEY = 'dsv';
  const BACKUP_KEY = 'dsv_v17_last_verified';
  let lastVerifiedAt = 0;
  let restoreState = 'none';

  function readObject(key) {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) return { ok: false, kind: 'missing', raw: null, data: null };
      const data = JSON.parse(raw);
      if (!data || typeof data !== 'object' || Array.isArray(data)) {
        return { ok: false, kind: 'invalid', raw, data: null };
      }
      return { ok: true, kind: 'valid', raw, data };
    } catch (error) {
      return { ok: false, kind: 'invalid', raw: null, data: null };
    }
  }

  function restoreVerifiedCopy() {
    const primary = readObject(SAVE_KEY);
    if (primary.ok) {
      restoreState = 'primary-valid';
      return false;
    }

    const backup = readObject(BACKUP_KEY);
    if (!backup.ok) {
      restoreState = primary.kind === 'missing' ? 'no-save' : 'no-valid-copy';
      return false;
    }

    try {
      if (typeof saveD !== 'undefined' && saveD && Object.keys(saveD).length === 0) {
        Object.assign(saveD, backup.data);
      }
      localStorage.setItem(SAVE_KEY, backup.raw);
      if (Array.isArray(backup.data.prem)) {
        try { localStorage.setItem('dsp', JSON.stringify(backup.data.prem)); } catch (_) {}
        try {
          if (typeof own2 !== 'undefined' && Array.isArray(own2)) {
            own2.length = 0;
            backup.data.prem.forEach(id => own2.push(id));
          }
          if (typeof applyPrem === 'function') applyPrem();
        } catch (_) {}
      }
      const restored = readObject(SAVE_KEY);
      if (restored.ok && restored.raw === backup.raw) {
        restoreState = 'restored';
        console.info('[Dust Siege] Copie locale vérifiée restaurée.');
        return true;
      }
    } catch (error) {
      console.warn('[Dust Siege] Restauration locale impossible :', error);
    }
    restoreState = 'restore-failed';
    return false;
  }

  function verifyAndBackup() {
    try {
      if (typeof saveD === 'undefined' || !saveD) return false;
      const expected = JSON.stringify(saveD);
      const primary = localStorage.getItem(SAVE_KEY);
      if (typeof primary !== 'string' || primary !== expected) return false;

      // La sauvegarde principale est vérifiée avant d'actualiser la copie de secours.
      try {
        if (localStorage.getItem(BACKUP_KEY) !== primary) {
          localStorage.setItem(BACKUP_KEY, primary);
        }
      } catch (backupError) {
        console.warn('[Dust Siege] Copie de secours non actualisée :', backupError);
      }

      lastVerifiedAt = Date.now();
      window.__dsV17LastVerifiedAt = lastVerifiedAt;
      window.__dsV17SaveState = 'verified';
      return true;
    } catch (error) {
      window.__dsV17SaveState = 'error';
      console.warn('[Dust Siege] Vérification de sauvegarde impossible :', error);
      return false;
    }
  }

  // Au démarrage, récupère la dernière copie confirmée uniquement si la sauvegarde
  // principale est absente ou illisible. Une sauvegarde principale valide est prioritaire.
  restoreVerifiedCopy();

  // Vérifie chaque sauvegarde déjà déclenchée par le jeu sans changer ses appels.
  const originalSaveAcct = window.saveAcct;
  if (typeof originalSaveAcct === 'function' && !originalSaveAcct.__dsV17Wrapped) {
    const guardedSaveAcct = function () {
      let result;
      let thrown = null;
      try {
        result = originalSaveAcct.apply(this, arguments);
      } catch (error) {
        thrown = error;
      }

      const verified = verifyAndBackup();
      if (thrown && !verified) throw thrown;
      if (thrown && verified) {
        console.warn('[Dust Siege] Sauvegarde locale vérifiée malgré une erreur secondaire :', thrown);
      }
      return result;
    };
    Object.defineProperty(guardedSaveAcct, '__dsV17Wrapped', { value: true });
    window.saveAcct = guardedSaveAcct;
  }


  function saveAndVerify() {
    let thrown = null;
    try {
      if (typeof saveAcct === 'function') saveAcct(false);
      else if (typeof localSave === 'function') localSave();
    } catch (error) {
      thrown = error;
    }
    const verified = verifyAndBackup();
    if (thrown && !verified) console.warn('[Dust Siege] Sauvegarde manuelle impossible :', thrown);
    return verified;
  }

  function setText(id, value) {
    const node = document.getElementById(id);
    if (node) node.textContent = value;
  }

  function refreshPauseStatus() {
    const primary = readObject(SAVE_KEY);
    const verified = primary.ok && typeof saveD !== 'undefined' && primary.raw === JSON.stringify(saveD);
    const backup = readObject(BACKUP_KEY);
    let message;
    if (verified) message = 'Sauvegarde sur cet appareil : vérifiée';
    else if (primary.ok) message = 'Sauvegarde présente : vérification à refaire';
    else if (backup.ok) message = 'Sauvegarde principale absente/illisible : copie de secours disponible';
    else message = 'Sauvegarde locale non vérifiée';
    if (lastVerifiedAt) message += ' · dernière vérification ' + new Date(lastVerifiedAt).toLocaleTimeString();
    setText('ds-v17-save-status', message);
  }

  function refreshDiagnostics() {
    const primary = readObject(SAVE_KEY);
    const verified = primary.ok && typeof saveD !== 'undefined' && primary.raw === JSON.stringify(saveD);
    const backup = readObject(BACKUP_KEY);
    const saveLine = verified
      ? 'Sauvegarde locale : vérifiée'
      : backup.ok
        ? 'Sauvegarde locale : copie de secours disponible (principale à contrôler)'
        : primary.ok
          ? 'Sauvegarde locale : présente, mais non identique à l’état courant'
          : 'Sauvegarde locale : absente ou illisible';
    setText('ds-v17-diag-save', saveLine);
    setText('ds-v17-diag-backup', 'Copie de secours : ' + (backup.ok ? 'disponible' : 'pas encore créée'));

    let soldier = 'Soldat 3D : chargement en cours';
    try {
      if (typeof plModelReady !== 'undefined' && plModelReady) {
        if (typeof plMixer !== 'undefined' && plMixer) {
          const walk = typeof plAnimActions !== 'undefined' && !!plAnimActions.walk;
          const run = typeof plAnimActions !== 'undefined' && !!plAnimActions.run;
          soldier = 'Soldat 3D riggé : chargé · marche ' + (walk ? 'OK' : 'en attente') + ' · course ' + (run ? 'OK' : 'en attente');
        } else {
          soldier = 'Modèle 3D de secours : chargé';
        }
      }
    } catch (_) {
      soldier = 'Soldat 3D : état non déterminé';
    }
    setText('ds-v17-diag-soldier', soldier);

    let account = 'Compte : état non déterminé';
    try {
      account = typeof cloudSession !== 'undefined' && cloudSession
        ? 'Compte : session détectée · synchronisation cloud dépendante du serveur'
        : 'Compte : mode local / invité / non connecté';
    } catch (_) {}
    setText('ds-v17-diag-account', account + ' · réseau ' + (navigator.onLine ? 'disponible' : 'hors ligne'));
  }

  // Complète le diagnostic déjà présent ; aucun panneau ou bouton n'est ajouté au HUD.
  function installDiagnosticCard() {
    const panel = document.getElementById('ds-v10-panel');
    if (!panel || document.getElementById('ds-v17-integrity-card')) return;
    const card = document.createElement('div');
    card.className = 'ds-card';
    card.id = 'ds-v17-integrity-card';
    const heading = document.createElement('b');
    heading.textContent = 'VÉRIFICATION DU JEU';
    card.appendChild(heading);
    for (const id of ['ds-v17-diag-save', 'ds-v17-diag-backup', 'ds-v17-diag-soldier', 'ds-v17-diag-account']) {
      const line = document.createElement('p');
      line.id = id;
      line.style.margin = '7px 0';
      line.textContent = 'Lecture…';
      card.appendChild(line);
    }
    panel.appendChild(card);
    refreshDiagnostics();
  }

  installDiagnosticCard();
  const diagnosticButton = document.getElementById('ds-v10-open');
  if (diagnosticButton) diagnosticButton.addEventListener('click', () => window.setTimeout(refreshDiagnostics, 0));

  const pauseOverlay = document.getElementById('pvo');
  const manualButton = document.getElementById('ds-v16-manual-save');
  if (pauseOverlay && manualButton && !document.getElementById('ds-v17-save-status')) {
    const status = document.createElement('p');
    status.id = 'ds-v17-save-status';
    status.setAttribute('aria-live', 'polite');
    status.style.cssText = 'font:12px Arial,sans-serif;color:#d8d2c5;margin:6px 0 0;max-width:min(380px,90vw);text-align:center';
    manualButton.insertAdjacentElement('afterend', status);
    // Intercepte le clic avant l'ancien gestionnaire V16 pour ne jamais afficher
    // un succès si le navigateur a refusé l'écriture dans le stockage local.
    manualButton.addEventListener('click', event => {
      if (event) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
      const ok = saveAndVerify();
      manualButton.textContent = ok ? '✓ SAUVEGARDE LOCALE VÉRIFIÉE' : 'ÉCHEC : SAUVEGARDE NON VÉRIFIÉE';
      manualButton.disabled = !ok;
      refreshPauseStatus();
      window.setTimeout(() => {
        manualButton.textContent = '💾 SAUVEGARDER MA PROGRESSION';
        manualButton.disabled = false;
        refreshPauseStatus();
      }, 2600);
    }, { capture: true });
    refreshPauseStatus();
  }

  // Le diagnostic est rafraîchi uniquement quand sa fenêtre est visible.
  window.setInterval(() => {
    const panel = document.getElementById('ds-v10-panel');
    if (panel && panel.style.display !== 'none') refreshDiagnostics();
  }, 3500);

  window.dsV17SaveIntegrity = {
    version: 17,
    verifyAndBackup,
    saveAndVerify,
    refreshDiagnostics,
    get lastVerifiedAt() { return lastVerifiedAt; },
    get restoreState() { return restoreState; }
  };
})();
