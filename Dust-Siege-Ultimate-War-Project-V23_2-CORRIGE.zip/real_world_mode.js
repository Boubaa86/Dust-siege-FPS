/* DUST SIEGE — REAL WORLD (phase 1)
 * France-first location picker + IGN aerial imagery + OSM building-mass 3D preview.
 * Additive module: does not replace the existing game scene, HUD, controls or saves.
 */
(() => {
  'use strict';
  if (window.__DS_REAL_WORLD_INSTALLED) return;
  window.__DS_REAL_WORLD_INSTALLED = true;

  const IGN_GEOCODE = 'https://data.geopf.fr/geocodage/search';
  const IGN_WMS = 'https://data.geopf.fr/wms-r?';
  const OVERPASS = [
    'https://overpass-api.de/api/interpreter',
    'https://overpass.kumi.systems/api/interpreter'
  ];
  const DEFAULT_CENTER = [46.60, 2.45]; // centre approximatif de la France métropolitaine
  const AREA_RADIUS_M = 1000; // zone de 2 km de diamètre

  const css = document.createElement('style');
  css.id = 'ds-real-world-style';
  css.textContent = `
    #dsrw-modal{position:fixed;inset:0;z-index:20000;display:none;overflow-y:auto;overscroll-behavior:contain;background:rgba(5,8,10,.98);color:#f3e6cf;padding:calc(12px + env(safe-area-inset-top,0px)) 12px calc(16px + env(safe-area-inset-bottom,0px));box-sizing:border-box;font-family:Arial,sans-serif;touch-action:pan-y}
    #dsrw-modal *{box-sizing:border-box}
    #dsrw-modal .dsrw-shell{max-width:850px;margin:0 auto}
    #dsrw-modal h2{margin:4px 0 6px;color:#e0ad51;font-size:25px;letter-spacing:1px;text-align:center}
    #dsrw-modal p{font-size:13px;line-height:1.45;color:#e2d8c6;text-align:center;margin:6px auto 12px;max-width:700px}
    #dsrw-modal .dsrw-row{display:flex;gap:8px;flex-wrap:wrap;align-items:stretch;margin:9px 0}
    #dsrw-modal input,#dsrw-modal select{min-width:0;flex:1;background:#171b1e;color:#fff;border:1px solid #9c7b43;border-radius:8px;padding:12px;font-size:16px;touch-action:manipulation}
    #dsrw-modal button{transform:none!important;margin:0!important;border-radius:9px!important;padding:11px 14px!important;font:bold 14px Arial,sans-serif!important;letter-spacing:.2px!important;min-height:44px;touch-action:manipulation;-webkit-tap-highlight-color:transparent}
    #dsrw-modal .dsrw-primary{background:#d9a441!important;color:#1a1208!important;border:1px solid #f1ca76!important}
    #dsrw-modal .dsrw-secondary{background:#222a30!important;color:#f3e6cf!important;border:1px solid #6d7780!important}
    #dsrw-modal .dsrw-status{min-height:22px;color:#d9bd83;font-size:13px;text-align:center;padding:5px 4px}
    #dsrw-map{height:300px;width:100%;border:1px solid #a9874e;border-radius:10px;overflow:hidden;background:#24313a;touch-action:pan-x pan-y;z-index:0}
    #dsrw-map .leaflet-control-attribution{font:10px Arial,sans-serif}
    #dsrw-results{display:grid;gap:6px;margin:7px 0}
    #dsrw-results button{width:100%;text-align:left;white-space:normal;line-height:1.35;background:#1b242a!important;color:#f3e6cf!important;border:1px solid #52616a!important}
    #dsrw-results button small{display:block;opacity:.7;font-weight:normal;margin-top:3px}
    #dsrw-selected{border:1px solid #6e603e;border-radius:8px;padding:9px;background:#171b1e;font-size:13px;text-align:center;margin:8px 0}
    #dsrw-preview{display:none;margin-top:10px}
    #dsrw-canvas{display:block;width:100%;height:min(58vh,480px);min-height:260px;background:#111923;border:1px solid #a9874e;border-radius:10px;touch-action:none}
    #dsrw-credits{font-size:10px!important;opacity:.76;margin:10px auto 2px!important}
    #dsrw-modal .dsrw-pill{display:inline-block;border:1px solid #806b42;border-radius:20px;padding:5px 9px;color:#e8ca8e;font-size:11px}
    @media(max-width:520px){#dsrw-map{height:260px}#dsrw-modal h2{font-size:21px}#dsrw-modal .dsrw-row button{flex:1}}
  `;
  document.head.appendChild(css);

  const modal = document.createElement('section');
  modal.id = 'dsrw-modal';
  modal.setAttribute('role', 'dialog');
  modal.setAttribute('aria-modal', 'true');
  modal.setAttribute('aria-label', 'Mode Real World');
  modal.innerHTML = `
    <div class="dsrw-shell">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:8px">
        <span class="dsrw-pill">FRANCE · BÊTA</span>
        <button id="dsrw-close" class="dsrw-secondary" type="button">FERMER ✕</button>
      </div>
      <h2>REAL WORLD</h2>
      <p>Choisis une zone réelle de 2 km. La localisation GPS est facultative : tu peux rechercher une ville, une adresse ou toucher directement la carte.</p>
      <div class="dsrw-row">
        <input id="dsrw-query" type="search" placeholder="Ville, adresse ou lieu en France…" autocomplete="off" enterkeyhint="search" aria-label="Rechercher un lieu en France">
        <button id="dsrw-search" class="dsrw-primary" type="button">RECHERCHER</button>
      </div>
      <div class="dsrw-row">
        <button id="dsrw-gps" class="dsrw-secondary" type="button">📍 UTILISER MA POSITION</button>
        <button id="dsrw-center" class="dsrw-secondary" type="button">CENTRER SUR LA FRANCE</button>
      </div>
      <div id="dsrw-status" class="dsrw-status" aria-live="polite">Recherche ou GPS facultatif. Tu peux aussi toucher la carte pour choisir un point.</div>
      <div id="dsrw-results"></div>
      <div id="dsrw-map" aria-label="Carte aérienne de France : toucher pour choisir un lieu"></div>
      <div id="dsrw-selected">Aucun lieu sélectionné pour le moment.</div>
      <div id="dsrw-picker-actions" class="dsrw-row">
        <button id="dsrw-build" class="dsrw-primary" type="button" disabled>CRÉER L’APERÇU 3D</button>
      </div>
      <div id="dsrw-preview">
        <div class="dsrw-row" style="justify-content:space-between;align-items:center">
          <b style="color:#e0ad51">APERÇU 3D DE LA ZONE</b>
          <button id="dsrw-back" class="dsrw-secondary" type="button">RETOUR À LA CARTE</button>
          <button id="dsrw-play" class="dsrw-primary" type="button">JOUER DANS CETTE ZONE</button>
        </div>
        <canvas id="dsrw-canvas" aria-label="Aperçu 3D du paysage et des bâtiments"></canvas>
        <div id="dsrw-3d-status" class="dsrw-status" aria-live="polite">Préparation de la zone…</div>
        <p>Fais glisser pour tourner autour de la zone et utilise le zoom pour regarder les bâtiments.</p>
      </div>
      <p id="dsrw-credits">Photographies aériennes : © IGN – Géoplateforme. Bâtiments : © contributeurs OpenStreetMap, données sous licence ODbL. Données ouvertes IGN et OpenStreetMap. Relief et façades détaillées en cours d’amélioration.</p>
    </div>`;
  document.body.appendChild(modal);

  const $ = id => document.getElementById(id);
  const state = { map: null, marker: null, circle: null, selected: null, leafletReady: null, renderer: null, raf: 0, previewScene: null, previewCamera: null, drag: null, yaw: .55, pitch: .75, distance: 1850, mapLayer: null, planLayer: null, baseNodes: [...scene.children], gameActive: false, originalPush: push, originalMkEn: mkEn };
  const status = message => { $('dsrw-status').textContent = message; };
  const previewStatus = message => { $('dsrw-3d-status').textContent = message; };

  function showModal() {
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
    loadLeaflet().then(() => {
      initMap();
      setTimeout(() => state.map && state.map.invalidateSize(true), 120);
    }).catch(err => status('La carte n’a pas pu être chargée. Vérifie Internet, ou utilise la recherche puis réessaie.'));
  }
  function hideModal() {
    stopPreview();
    modal.style.display = 'none';
    document.body.style.overflow = '';
  }
  $('dsrw-close').addEventListener('click', hideModal);

  function loadLeaflet() {
    if (window.L) return Promise.resolve();
    if (state.leafletReady) return state.leafletReady;
    state.leafletReady = new Promise((resolve, reject) => {
      if (!document.querySelector('link[data-dsrw-leaflet]')) {
        const link = document.createElement('link'); link.rel = 'stylesheet';
        link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'; link.dataset.dsrwLeaflet = '1';
        document.head.appendChild(link);
      }
      const script = document.createElement('script');
      script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      script.onload = resolve; script.onerror = () => reject(new Error('Leaflet indisponible'));
      document.head.appendChild(script);
    });
    return state.leafletReady;
  }

  function initMap() {
    if (state.map || !window.L) return;
    const L = window.L;
    state.map = L.map('dsrw-map', { zoomControl: true, attributionControl: true, preferCanvas: true }).setView(DEFAULT_CENTER, 6);
    state.mapLayer = L.tileLayer.wms(IGN_WMS, {
      layers: 'ORTHOIMAGERY.ORTHOPHOTOS', styles: '', format: 'image/jpeg',
      version: '1.3.0', transparent: false, attribution: '© IGN – Géoplateforme'
    }).addTo(state.map);
    state.planLayer = L.tileLayer.wms(IGN_WMS, {
      layers: 'GEOGRAPHICALGRIDSYSTEMS.PLANIGNV2', styles: '', format: 'image/png',
      version: '1.3.0', transparent: false, attribution: '© IGN – Géoplateforme'
    });
    L.control.layers({ 'Photo aérienne IGN': state.mapLayer, 'Plan IGN': state.planLayer }, null, { position: 'topright', collapsed: true }).addTo(state.map);
    L.control.scale({ metric: true, imperial: false }).addTo(state.map);
    state.map.on('click', ev => chooseLocation(ev.latlng.lat, ev.latlng.lng, 'Point choisi sur la carte', true));
    status('Carte IGN chargée. Recherche une ville ou touche la carte pour choisir ton emplacement.');
  }

  function chooseLocation(lat, lon, label, zoomMap) {
    if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 85 || Math.abs(lon) > 180) return;
    state.selected = { lat, lon, label: String(label || 'Lieu sélectionné').slice(0, 180), radius: AREA_RADIUS_M };
    if (state.map && window.L) {
      if (state.marker) state.map.removeLayer(state.marker);
      if (state.circle) state.map.removeLayer(state.circle);
      state.marker = window.L.marker([lat, lon]).addTo(state.map);
      state.circle = window.L.circle([lat, lon], { radius: AREA_RADIUS_M, color: '#e6b654', weight: 2, fillColor: '#e6b654', fillOpacity: .10 }).addTo(state.map);
      if (zoomMap) state.map.setView([lat, lon], 15);
    }
    $('dsrw-selected').textContent = state.selected.label + ' · ' + lat.toFixed(5) + ', ' + lon.toFixed(5) + ' · zone de 2 km';
    $('dsrw-build').disabled = false;
    try { localStorage.setItem('dsRealWorldPlace', JSON.stringify(state.selected)); } catch (_) {}
    status('Lieu sélectionné. Tu peux créer son aperçu 3D.');
  }

  async function searchPlace() {
    const query = $('dsrw-query').value.trim();
    if (query.length < 2) { status('Écris au moins 2 caractères pour rechercher un lieu.'); return; }
    $('dsrw-results').innerHTML = '';
    status('Recherche dans les adresses et lieux de France…');
    $('dsrw-search').disabled = true;
    try {
      const searchIndex = async index => {
        const url = IGN_GEOCODE + '?' + new URLSearchParams({ q: query, index, limit: '6', returntruegeometry: 'false' });
        const response = await fetch(url, { method: 'GET', headers: { 'Accept': 'application/json' }, cache: 'no-store' });
        if (!response.ok) throw new Error('Service IGN indisponible (' + response.status + ')');
        const data = await response.json();
        return Array.isArray(data.features) ? data.features : (Array.isArray(data.results) ? data.results : []);
      };
      const answers = await Promise.allSettled([searchIndex('address'), searchIndex('poi')]);
      const features = answers.filter(x => x.status === 'fulfilled').flatMap(x => x.value);
      const unique = new Map();
      for (const feature of features) {
        const c = feature.geometry && feature.geometry.coordinates;
        const label = feature.properties && (feature.properties.label || feature.properties.name);
        if (Array.isArray(c) && c.length >= 2) unique.set(String(label || c.join(',')) + ':' + c.join(','), feature);
      }
      const results = [...unique.values()];
      if (!results.length) {
        const rejected = answers.find(x => x.status === 'rejected');
        if (rejected) throw rejected.reason;
        status('Aucun résultat trouvé. Essaie avec le nom de la ville ou une adresse plus précise.'); return;
      }
      const list = $('dsrw-results');
      results.slice(0, 8).forEach(feature => {
        const coords = feature.geometry && feature.geometry.coordinates;
        if (!Array.isArray(coords) || coords.length < 2) return;
        const props = feature.properties || {};
        const label = props.label || props.name || props.toponym || query;
        const detail = [props.postcode, props.city, props.context].filter(Boolean).join(' · ');
        const b = document.createElement('button'); b.type = 'button';
        b.innerHTML = '';
        const title = document.createElement('span'); title.textContent = label;
        const small = document.createElement('small'); small.textContent = detail || 'Lieu en France';
        b.append(title, small);
        b.addEventListener('click', () => { chooseLocation(Number(coords[1]), Number(coords[0]), label, true); list.innerHTML = ''; });
        list.appendChild(b);
      });
      status('Choisis un résultat, ou touche un autre point sur la carte.');
      if (!list.children.length) status('Les résultats reçus ne contiennent pas de coordonnées utilisables.');
    } catch (err) {
      status('Recherche impossible pour le moment : ' + err.message + '. Tu peux toujours déplacer la carte et toucher un point.');
    } finally { $('dsrw-search').disabled = false; }
  }
  $('dsrw-search').addEventListener('click', searchPlace);
  $('dsrw-query').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); searchPlace(); } });

  $('dsrw-gps').addEventListener('click', () => {
    if (!navigator.geolocation) { status('GPS non disponible dans cette application. Utilise la recherche manuelle.'); return; }
    status('Demande d’autorisation GPS… Tu peux refuser et continuer avec la recherche manuelle.');
    navigator.geolocation.getCurrentPosition(
      p => chooseLocation(p.coords.latitude, p.coords.longitude, 'Ma position (GPS)', true),
      err => status(err.code === 1 ? 'Accès GPS refusé. Aucun problème : recherche une ville ou une adresse à la place.' : 'Position GPS indisponible. La recherche manuelle reste disponible.'),
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 60000 }
    );
  });
  $('dsrw-center').addEventListener('click', () => { if (state.map) state.map.setView(DEFAULT_CENTER, 6); status('Carte recentrée sur la France.'); });

  function mercator(lon, lat) {
    const r = 6378137, x = r * lon * Math.PI / 180;
    const safeLat = Math.max(-85.0511, Math.min(85.0511, lat));
    const y = r * Math.log(Math.tan(Math.PI / 4 + safeLat * Math.PI / 360));
    return [x, y];
  }
  function orthoUrl(place) {
    const [x, y] = mercator(place.lon, place.lat), r = place.radius / Math.max(.15, Math.cos(place.lat * Math.PI / 180));
    const params = new URLSearchParams({
      LAYERS: 'ORTHOIMAGERY.ORTHOPHOTOS', FORMAT: 'image/jpeg', SERVICE: 'WMS',
      VERSION: '1.3.0', REQUEST: 'GetMap', STYLES: '', CRS: 'EPSG:3857',
      BBOX: [x-r, y-r, x+r, y+r].join(','), WIDTH: '2048', HEIGHT: '2048'
    });
    return IGN_WMS + params.toString();
  }

  async function fetchBuildings(place) {
    const dLat = place.radius / 111320;
    const dLon = place.radius / (111320 * Math.max(.15, Math.cos(place.lat * Math.PI / 180)));
    const south = place.lat - dLat, north = place.lat + dLat;
    const west = place.lon - dLon, east = place.lon + dLon;
    const bbox = [south, west, north, east].join(',');
    const query = `[out:json][timeout:28];(way["building"](${bbox});way["highway"~"^(primary|secondary|tertiary|residential|unclassified|service|living_street)$"](${bbox}););out body geom;`;
    let lastError;
    for (const endpoint of OVERPASS) {
      try {
        const response = await fetch(endpoint, {
          method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'Accept': 'application/json' },
          body: 'data=' + encodeURIComponent(query), signal: (typeof AbortSignal !== 'undefined' && AbortSignal.timeout) ? AbortSignal.timeout(18000) : undefined
        });
        if (!response.ok) throw new Error('OpenStreetMap ' + response.status);
        const data = await response.json();
        const valid = (data.elements || []).filter(e => e.type === 'way' && Array.isArray(e.geometry) && e.geometry.length >= 2);
        const b = valid.filter(e => e.tags && e.tags.building).slice(0, 480);
        const r = valid.filter(e => e.tags && e.tags.highway).slice(0, 180);
        return b.concat(r);
      } catch (e) { lastError = e; }
    }
    throw lastError || new Error('Données de bâtiments indisponibles');
  }

  function buildingHeight(tags) {
    const raw = parseFloat(String((tags && (tags.height || tags['building:height'])) || '').replace(',', '.'));
    if (Number.isFinite(raw) && raw >= 2 && raw <= 100) return raw;
    const levels = parseFloat(tags && tags['building:levels']);
    if (Number.isFinite(levels) && levels >= 1 && levels <= 30) return Math.max(3, levels * 3.1);
    return 6.2;
  }
  function buildingMaterial(tags, index) {
    const kind = (tags && (tags.building || tags.amenity || tags.shop)) || '';
    let color = 0xb8a98e;
    if (/industrial|warehouse|garages/.test(kind)) color = 0x8c9290;
    else if (/church|cathedral|chapel/.test(kind)) color = 0xc9bda5;
    else if (/commercial|retail|office/.test(kind)) color = 0xa9a49a;
    else if (index % 7 === 0) color = 0xa77d64;
    return new T.MeshStandardMaterial({ color, roughness: .92, metalness: .02 });
  }

  async function buildPreview() {
    if (!state.selected) return;
    $('dsrw-picker-actions').style.display = 'none';
    $('dsrw-map').style.display = 'none'; $('dsrw-results').style.display = 'none';
    $('dsrw-query').parentElement.style.display = 'none';
    $('dsrw-gps').parentElement.style.display = 'none'; $('dsrw-selected').style.display = 'none';
    $('dsrw-preview').style.display = 'block';
    previewStatus('Téléchargement de la photo aérienne IGN et des empreintes de bâtiments OpenStreetMap…');
    try {
      await renderWorld(state.selected);
    } catch (err) {
      stopPreview();
      previewStatus('Aperçu partiel : ' + err.message + '. La carte de sélection et la recherche restent disponibles.');
    }
  }

  function backToPicker() {
    stopPreview(); $('dsrw-preview').style.display = 'none';
    $('dsrw-picker-actions').style.display = 'flex'; $('dsrw-map').style.display = 'block';
    $('dsrw-results').style.display = 'grid'; $('dsrw-query').parentElement.style.display = 'flex';
    $('dsrw-gps').parentElement.style.display = 'flex'; $('dsrw-selected').style.display = 'block';
    setTimeout(() => state.map && state.map.invalidateSize(true), 80);
  }
  $('dsrw-back').addEventListener('click', backToPicker);
  $('dsrw-play').addEventListener('click', startRealWorldGame);
  $('dsrw-build').addEventListener('click', buildPreview);

  async function renderWorld(place) {
    if (!window.THREE) throw new Error('Moteur 3D indisponible');
    stopPreview();
    const T = window.THREE, canvas = $('dsrw-canvas');
    const width = Math.max(320, canvas.clientWidth || 320), height = Math.max(260, canvas.clientHeight || 320);
    const renderer = new T.WebGLRenderer({ canvas, antialias: true, powerPreference: 'low-power', alpha: false });
    state.renderer = renderer; renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.25)); renderer.setSize(width, height, false);
    if (renderer.outputColorSpace !== undefined && T.SRGBColorSpace) renderer.outputColorSpace = T.SRGBColorSpace;
    else if ('outputEncoding' in renderer && T.sRGBEncoding) renderer.outputEncoding = T.sRGBEncoding;
    const scene = new T.Scene(); scene.background = new T.Color(0x111923); state.previewScene = scene;
    const camera = new T.PerspectiveCamera(48, width / height, 1, 12000); state.previewCamera = camera;
    scene.add(new T.HemisphereLight(0xffffff, 0x3d352d, 1.4));
    const sun = new T.DirectionalLight(0xffe0b0, 2); sun.position.set(-500, 900, 500); scene.add(sun);
    const size = place.radius * 2;
    const fallback = new T.Mesh(new T.PlaneGeometry(size, size), new T.MeshStandardMaterial({ color: 0x65774a, roughness: 1 }));
    fallback.rotation.x = -Math.PI / 2; fallback.position.y = -1; scene.add(fallback);
    const textureLoader = new T.TextureLoader(); textureLoader.setCrossOrigin('anonymous');
    const imageTexture = await new Promise((resolve, reject) => textureLoader.load(orthoUrl(place), resolve, undefined, reject));
    if (imageTexture.colorSpace !== undefined && T.SRGBColorSpace) imageTexture.colorSpace = T.SRGBColorSpace;
    else if ('encoding' in imageTexture && T.sRGBEncoding) imageTexture.encoding = T.sRGBEncoding;
    const terrain = new T.Mesh(new T.PlaneGeometry(size, size), new T.MeshBasicMaterial({ map: imageTexture }));
    terrain.userData.dsRealTerrain = true;
    terrain.rotation.x = -Math.PI / 2; terrain.position.y = 0; terrain.receiveShadow = true; scene.add(terrain); fallback.visible = false;

    let buildings = [];
    try { buildings = await fetchBuildings(place); } catch (e) { previewStatus('Photo IGN chargée. Les bâtiments OSM ne répondent pas pour le moment : ' + e.message); }
    let count = 0;
    for (let i = 0; i < buildings.length; i++) {
      const element = buildings[i], geom = element.geometry;
      if (!(element.tags && element.tags.building) || !geom || geom.length < 4) continue;
      const coords = geom.slice(0, 180);
      const shape = new T.Shape();
      let valid = true;
      coords.forEach((pt, j) => {
        const x = (pt.lon - place.lon) * 111320 * Math.cos(place.lat * Math.PI / 180);
        const north = (pt.lat - place.lat) * 111320;
        if (!Number.isFinite(x) || !Number.isFinite(north)) { valid = false; return; }
        if (j === 0) shape.moveTo(x, north); else shape.lineTo(x, north);
      });
      if (!valid) continue;
      shape.closePath();
      const h = buildingHeight(element.tags || {});
      try {
        const geometry = new T.ExtrudeGeometry(shape, { depth: h, bevelEnabled: false, curveSegments: 1 });
        geometry.rotateX(-Math.PI / 2);
        const mesh = new T.Mesh(geometry, buildingMaterial(element.tags || {}, i));
        const xs = [], zs = [];
        for (const pt of coords) {
          xs.push((pt.lon - place.lon) * 111320 * Math.cos(place.lat * Math.PI / 180));
          zs.push(-(pt.lat - place.lat) * 111320);
        }
        mesh.userData.dsRealBuilding = true;
        mesh.userData.dsRealBounds = { a: Math.min(...xs), b: Math.min(...zs), c: Math.max(...xs), d: Math.max(...zs), h };
        mesh.position.y = 0.2; mesh.castShadow = true; mesh.receiveShadow = true; scene.add(mesh); count++;
      } catch (_) { /* ignore invalid footprints */ }
    }
    let roadCount = 0;
    for (const element of buildings) {
      const highway = element.tags && element.tags.highway;
      const geom = element.geometry;
      if (!highway || !Array.isArray(geom) || geom.length < 2) continue;
      const width = highway === 'primary' ? 9 : highway === 'secondary' ? 7 : highway === 'tertiary' ? 5.5 : highway === 'residential' ? 4.2 : 3.2;
      const vertices = [];
      for (let i = 1; i < geom.length; i++) {
        const a = geom[i - 1], b = geom[i];
        const ax = (a.lon - place.lon) * 111320 * Math.cos(place.lat * Math.PI / 180);
        const az = -(a.lat - place.lat) * 111320;
        const bx = (b.lon - place.lon) * 111320 * Math.cos(place.lat * Math.PI / 180);
        const bz = -(b.lat - place.lat) * 111320;
        const dx = bx - ax, dz = bz - az, len = Math.hypot(dx, dz);
        if (len < .5) continue;
        const nx = -dz / len * width / 2, nz = dx / len * width / 2;
        vertices.push(ax + nx, .13, az + nz, ax - nx, .13, az - nz, bx + nx, .13, bz + nz);
        vertices.push(ax - nx, .13, az - nz, bx - nx, .13, bz - nz, bx + nx, .13, bz + nz);
      }
      if (vertices.length) {
        const roadGeometry = new T.BufferGeometry();
        roadGeometry.setAttribute('position', new T.Float32BufferAttribute(vertices, 3));
        roadGeometry.computeVertexNormals();
        const road = new T.Mesh(roadGeometry, new T.MeshStandardMaterial({ color: 0x45494b, roughness: .98, side: T.DoubleSide }));
        road.userData.dsRealRoad = true; scene.add(road); roadCount++;
      }
    }
    const groundRing = new T.Mesh(new T.RingGeometry(size * .493, size * .5, 96), new T.MeshBasicMaterial({ color: 0xd8aa59, side: T.DoubleSide }));
    groundRing.rotation.x = -Math.PI / 2; groundRing.position.y = .15; scene.add(groundRing);

    state.yaw = .55; state.pitch = .75; state.distance = size * .92;
    function updateCamera() {
      const d = state.distance, p = Math.max(.2, Math.min(1.35, state.pitch));
      camera.position.set(Math.sin(state.yaw) * d, Math.sin(p) * d * .72 + 90, Math.cos(state.yaw) * d);
      camera.lookAt(0, 0, 0);
    }
    updateCamera();
    let alive = true;
    const animate = () => {
      if (!alive || !state.renderer) return;
      updateCamera(); state.renderer.render(scene, camera); state.raf = requestAnimationFrame(animate);
    };
    state.previewStop = () => { alive = false; };
    animate();
    attachPreviewControls(canvas);
    previewStatus('Zone prête : ' + count + ' bâtiments 3D et ' + roadCount + ' routes OpenStreetMap. Paysage texturé par la photo aérienne IGN. Appuie sur « JOUER DANS CETTE ZONE » pour démarrer une partie.');
  }

  function startRealWorldGame() {
    if (!state.selected || !state.previewScene) { previewStatus('Crée d’abord l’aperçu 3D de cette zone.'); return; }
    try {
      if (typeof LOGIN !== 'undefined' && LOGIN && typeof uid !== 'undefined' && !uid && typeof guest !== 'undefined' && !guest) {
        const loginPanel = $('lge') && $('lge').closest('.ov');
        if (loginPanel) { loginPanel.style.setProperty('z-index', '20050', 'important'); loginPanel.style.display = 'flex'; }
        previewStatus('Connecte-toi ou choisis « jouer sans sauvegarde » pour démarrer la partie.');
        return;
      }
    } catch (_) {}

    const T = window.THREE;
    // Hide only the original environment objects. Keep the camera, sky and lights.
    for (const object of state.baseNodes) {
      if (object && object !== cam && object !== sky && !object.isCamera && !object.isLight) object.visible = false;
    }
    // Replace the old small-map collision set with the selected real-world buildings.
    obs.length = 0; om.length = 0;
    for (const object of [...state.previewScene.children]) {
      if (!object.isMesh) continue;
      state.previewScene.remove(object);
      scene.add(object);
      if (object.userData && object.userData.dsRealBuilding) {
        const bounds = object.userData.dsRealBounds;
        if (bounds) obs.push(bounds);
        om.push(object);
      }
    }
    state.gameActive = true;
    const worldLimit = state.selected.radius - 8;
    push = function(p, r) {
      for (const o of obs) {
        if (p === pos && jy > o.h - .1) continue;
        const cx = Math.max(o.a, Math.min(p.x, o.c));
        const cz = Math.max(o.b, Math.min(p.z, o.d));
        let dx = p.x - cx, dz = p.z - cz, d = dx * dx + dz * dz;
        if (d < r * r) {
          if (d > 1e-6) { d = Math.sqrt(d); p.x = cx + dx / d * r; p.z = cz + dz / d * r; }
          else p.x += r;
        }
      }
      p.x = Math.max(-worldLimit, Math.min(worldLimit, p.x));
      p.z = Math.max(-worldLimit, Math.min(worldLimit, p.z));
    };
    // Keep enemy waves close to the player and inside the larger selected area.
    mkEn = function(x, z, boss) {
      if (state.gameActive) {
        const a = R() * Math.PI * 2, d = 30 + R() * 24;
        x = Math.max(-worldLimit, Math.min(worldLimit, pos.x + Math.cos(a) * d));
        z = Math.max(-worldLimit, Math.min(worldLimit, pos.z + Math.sin(a) * d));
      }
      return state.originalMkEn(x, z, boss);
    };
    scene.fog = new T.Fog(0x9aa9a2, 260, state.selected.radius * 2.1);
    cam.far = state.selected.radius * 3.2; cam.updateProjectionMatrix();
    const followSky = () => {
      if (!state.gameActive) return;
      if (sky) sky.position.copy(cam.position);
      state.skyRaf = requestAnimationFrame(followSky);
    };
    followSky();

    // Find a nearby point that is not inside one of the building bounding boxes.
    let spawn = { x: 0, z: 0 }, found = false;
    for (let radius = 0; radius <= 90 && !found; radius += 4) {
      for (let a = 0; a < Math.PI * 2; a += Math.PI / 8) {
        const x = Math.cos(a) * radius, z = Math.sin(a) * radius;
        const blocked = obs.some(o => x > o.a - 1.2 && x < o.c + 1.2 && z > o.b - 1.2 && z < o.d + 1.2);
        if (!blocked) { spawn = { x, z }; found = true; break; }
      }
    }

    state.previewScene = null;
    hideModal();
    mode = 'real';
    $('go').click();
    pos.set(spawn.x, 1.7, spawn.z); push(pos, .55); yaw = 0; pitch = 0; hud();
    banner('REAL WORLD · ' + state.selected.label.toUpperCase());
    say('Zone réelle chargée. Repère les bâtiments et reste en mouvement !');
  }

  function attachPreviewControls(canvas) {
    const down = e => { state.drag = { x: e.clientX, y: e.clientY, yaw: state.yaw, pitch: state.pitch }; try { canvas.setPointerCapture(e.pointerId); } catch (_) {} };
    const move = e => { if (!state.drag) return; state.yaw = state.drag.yaw - (e.clientX - state.drag.x) * .006; state.pitch = Math.max(.2, Math.min(1.35, state.drag.pitch + (e.clientY - state.drag.y) * .004)); };
    const up = () => { state.drag = null; };
    const wheel = e => { e.preventDefault(); state.distance = Math.max(250, Math.min(4500, state.distance * (e.deltaY > 0 ? 1.1 : .9))); };
    canvas.addEventListener('pointerdown', down); canvas.addEventListener('pointermove', move); canvas.addEventListener('pointerup', up); canvas.addEventListener('pointercancel', up); canvas.addEventListener('wheel', wheel, { passive: false });
    state.controlCleanup = () => { canvas.removeEventListener('pointerdown', down); canvas.removeEventListener('pointermove', move); canvas.removeEventListener('pointerup', up); canvas.removeEventListener('pointercancel', up); canvas.removeEventListener('wheel', wheel); };
  }

  function stopPreview() {
    if (state.previewStop) { state.previewStop(); state.previewStop = null; }
    if (state.raf) cancelAnimationFrame(state.raf); state.raf = 0;
    if (state.controlCleanup) { state.controlCleanup(); state.controlCleanup = null; }
    if (state.renderer) { try { state.renderer.dispose(); } catch (_) {} state.renderer = null; }
    state.previewScene = null; state.previewCamera = null; state.drag = null;
  }

  // Add a dedicated card to the existing menu without changing the original modes.
  const modes = document.getElementById('modes');
  if (modes && !document.getElementById('dsrw-open')) {
    const button = document.createElement('button');
    button.id = 'dsrw-open'; button.type = 'button'; button.className = 'mc';
    button.innerHTML = '<span class="mi">🌍</span><span>REAL WORLD<small>Choisis une ville réelle · aperçu 3D</small></span>';
    button.addEventListener('click', showModal);
    modes.appendChild(button);
  }
  window.dsRealWorld = {
    open: showModal,
    getSelectedPlace: () => state.selected ? { ...state.selected } : null,
    savedPlace: () => { try { return JSON.parse(localStorage.getItem('dsRealWorldPlace') || 'null'); } catch (_) { return null; } },
    isPlayingRealWorld: () => state.gameActive
  };
})();
