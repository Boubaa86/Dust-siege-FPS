/* DUST SIEGE V10 — additive stability, mobile HUD and diagnostics pack */
(()=>{
  'use strict';
  const css=document.createElement('style');
  css.id='dust-siege-v10-mobile-fix';
  css.textContent=`
    /* The global canvas rule also targets the minimap: constrain it explicitly. */
    body > canvas { z-index:0 !important; }
    #hud { position:fixed !important; inset:0 !important; z-index:4 !important; pointer-events:none !important; }
    #hud canvas#rd { position:absolute !important; inset:auto !important; left:12px !important; top:calc(10px + env(safe-area-inset-top,0px)) !important; width:110px !important; height:110px !important; min-width:110px !important; min-height:110px !important; max-width:110px !important; max-height:110px !important; border-radius:50%; pointer-events:none !important; }
    #vig,#dmg { z-index:2 !important; }
    #tc { position:fixed !important; inset:0 !important; z-index:8 !important; pointer-events:none !important; }
    #tc .tb { pointer-events:auto !important; min-width:52px; min-height:52px; touch-action:none; -webkit-tap-highlight-color:transparent; }
    #ch,#hm,#di { z-index:5; pointer-events:none; }
    #cash,#score,#wave,#ammo,#hpw,#ban,#rad,#kf { z-index:5; }
    .tb:active { transform:scale(.94); filter:brightness(1.35); }
    #ds-v10-panel { position:fixed; inset:0; z-index:30; display:none; overflow:auto; padding:22px; box-sizing:border-box; background:rgba(5,8,12,.96); color:#f3e6cf; font:15px Arial,sans-serif; touch-action:pan-y; }
    #ds-v10-panel h2 { color:#d9a441; font: bold 25px Arial,sans-serif; }
    #ds-v10-panel .ds-card { max-width:520px; margin:8px auto; padding:12px; border:1px solid #d9a44166; border-radius:10px; background:#171717; text-align:left; }
    #ds-v10-panel button { font: bold 15px Arial,sans-serif; letter-spacing:0; transform:none; padding:10px 16px; margin:6px 4px; border-radius:8px; }
    #ds-v10-panel button.ds-secondary { background:#333; color:#fff; border:1px solid #888; }
    @media (prefers-reduced-motion: reduce) { *,*::before,*::after { scroll-behavior:auto !important; animation-duration:.01ms !important; transition-duration:.01ms !important; } }
    @media (max-width:600px) { #ammo { font-size:clamp(24px,7vw,38px) !important; } #score,#cash { font-size:clamp(14px,4vw,19px) !important; } }
  `;
  document.head.appendChild(css);

  // Never force fullscreen/orientation: keep the phone's normal screen and browser controls.
  const menu=document.getElementById('menu');
  if(menu && !document.getElementById('ds-v10-open')){
    const open=document.createElement('button');
    open.id='ds-v10-open'; open.type='button'; open.textContent='DIAGNOSTIC & PERFORMANCES';
    open.style.cssText='transform:none;border-radius:20px;font-size:15px;padding:9px 18px;margin:0;background:#f3e6cf22;color:#f3e6cf;border:1px solid #f3e6cf55';
    menu.appendChild(open);
    const panel=document.createElement('section'); panel.id='ds-v10-panel'; panel.setAttribute('role','dialog'); panel.setAttribute('aria-modal','true');
    panel.innerHTML=`<h2>DIAGNOSTIC DUST SIEGE</h2>
      <div class="ds-card"><b>État du jeu</b><p id="ds-v10-status">Lecture…</p><p id="ds-v10-screen"></p><p id="ds-v10-network"></p><p id="ds-v10-fps">FPS : mesure en cours…</p><p id="ds-v10-webgl"></p></div>
      <div class="ds-card"><b>Qualité graphique adaptative</b><p>Le jeu peut réduire automatiquement certains effets si le téléphone ralentit, puis les réactiver quand les performances reviennent.</p><label><input id="ds-v10-auto" type="checkbox"> Activer l’ajustement automatique</label><p id="ds-v10-quality"></p></div>
      <div class="ds-card"><b>Contrôles conservés</b><p>Carte, argent, viseur, munitions, vie et boutons tactiles restent affichés au-dessus de la scène 3D. Cette mise à jour ne remplace pas les menus, les sauvegardes ou les fonctions sociales.</p></div>
      <button id="ds-v10-close" class="ds-secondary" type="button">RETOUR AU MENU</button>`;
    document.body.appendChild(panel);
    const auto=document.getElementById('ds-v10-auto');
    try{auto.checked=localStorage.getItem('dsV10AutoQuality')==='1'}catch(e){}
    const qLabel=document.getElementById('ds-v10-quality');
    const updateQualityLabel=()=>{qLabel.textContent='Qualité actuelle : '+(window.__dsV10Low?'Économie':'Élevée')};
    auto.addEventListener('change',()=>{try{localStorage.setItem('dsV10AutoQuality',auto.checked?'1':'0')}catch(e){}; if(!auto.checked){window.__dsV10Low=false; try{quality('hi')}catch(e){}} updateQualityLabel()});
    open.addEventListener('click',()=>{panel.style.display='block';
      document.getElementById('ds-v10-screen').textContent=`Écran : ${innerWidth} × ${innerHeight} · ${Math.round((devicePixelRatio||1)*100)} % densité`;
      document.getElementById('ds-v10-network').textContent='Réseau : '+(navigator.onLine?'connecté':'hors ligne');
      document.getElementById('ds-v10-status').textContent='Partie : '+(typeof playing!=='undefined'&&playing?'en cours':'menu / pause');
      try{const gl=document.querySelector('canvas').getContext('webgl2')||document.querySelector('canvas').getContext('webgl');document.getElementById('ds-v10-webgl').textContent='WebGL : '+(gl?'disponible':'non détecté')}catch(e){document.getElementById('ds-v10-webgl').textContent='WebGL : état non déterminé'}
      updateQualityLabel();
    });
    document.getElementById('ds-v10-close').addEventListener('click',()=>panel.style.display='none');
    panel.addEventListener('click',e=>{if(e.target===panel)panel.style.display='none'});
  }

  // Low-cost FPS sampling. Adaptive mode is opt-in and only changes renderer quality,
  // never game rules, controls, progression, or online state.
  let frames=0,last=performance.now(),lowFor=0,highFor=0,lastFps=0;
  const fpsNode=()=>document.getElementById('ds-v10-fps');
  function sample(now){
    frames++;
    const elapsed=now-last;
    if(elapsed>=1000){
      const fps=Math.round(frames*1000/elapsed); lastFps=fps; frames=0; last=now;
      const n=fpsNode(); if(n)n.textContent='FPS : '+fps;
      let enabled=false;try{enabled=localStorage.getItem('dsV10AutoQuality')==='1'}catch(e){}
      if(enabled){
        if(fps<27){lowFor+=elapsed;highFor=0}else if(fps>48){highFor+=elapsed;lowFor=0}else{lowFor=0;highFor=0}
        if(lowFor>=3500&&!window.__dsV10Low){try{quality('lo');window.__dsV10Low=true}catch(e){} lowFor=0}
        if(highFor>=9000&&window.__dsV10Low){try{quality('hi');window.__dsV10Low=false}catch(e){} highFor=0}
      }
    }
    requestAnimationFrame(sample);
  }
  requestAnimationFrame(sample);

  // Prevent the browser context menu from covering the firing controls during play.
  document.addEventListener('contextmenu',e=>{if(document.body.classList.contains('touch'))e.preventDefault()});
  // Short optional haptic confirmation on supported Android devices.
  document.addEventListener('pointerdown',e=>{
    if(e.target && e.target.classList && e.target.classList.contains('tb') && navigator.vibrate){try{navigator.vibrate(10)}catch(err){}}
  },{passive:true});
  addEventListener('online',()=>{const n=fpsNode();if(n)n.textContent='FPS : '+(lastFps||'—')+' · réseau rétabli'});
})();
